package poo;

import java.math.BigDecimal;
import java.time.LocalDate;

public interface CalcularPago {
    BigDecimal calcularPago(BigDecimal sueldo,BigDecimal bono);
}
