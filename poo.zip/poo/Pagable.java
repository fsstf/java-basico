package poo;

import java.math.BigDecimal;

public interface Pagable {
    BigDecimal calcularPago();
}
